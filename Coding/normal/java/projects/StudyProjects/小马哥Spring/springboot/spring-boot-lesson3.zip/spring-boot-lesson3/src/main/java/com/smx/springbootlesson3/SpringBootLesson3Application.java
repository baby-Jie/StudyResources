package com.smx.springbootlesson3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLesson3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootLesson3Application.class, args);
	}

}
